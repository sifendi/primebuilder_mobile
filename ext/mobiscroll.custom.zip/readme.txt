This is a commercial Mobiscroll package, licensed to Yatin Godse <yatin@experiencecommerce.com> with license key 5765a6f0-ab40-48ef-831c-0f007448bac3. 

Please refer to the EULA licensing terms (present in the license folder) or https://mobiscroll.com/EULA for more info.