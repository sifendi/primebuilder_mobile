// This is where you put the typescript code
import {
    Component
} from '@angular/core';

@Component({
    selector: 'demo-app',
    templateUrl: './app.component.html',
    moduleId: module.id
})

export class AppComponent {

}