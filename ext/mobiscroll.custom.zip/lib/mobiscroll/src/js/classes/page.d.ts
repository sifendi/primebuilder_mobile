import mobiscroll from '../core/core';
export default class Page {
    constructor(element: any, settings: any);
}