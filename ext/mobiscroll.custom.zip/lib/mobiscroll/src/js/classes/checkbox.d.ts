import mobiscroll from '../core/core';
export default class CheckBox {
    constructor(element: any, settings: any);
}