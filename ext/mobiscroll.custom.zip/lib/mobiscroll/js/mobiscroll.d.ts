import { mobiscroll } from '../src/js/modules/mobiscroll.angular';
export * from '../src/js/modules/mobiscroll.angular';
import '../src/js/themes/mobiscroll-dark';
import '../src/js/themes/auto-theme';
export default mobiscroll;
