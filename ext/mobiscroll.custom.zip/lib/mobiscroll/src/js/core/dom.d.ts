import mobiscroll from './mobiscroll';
export default mobiscroll;
